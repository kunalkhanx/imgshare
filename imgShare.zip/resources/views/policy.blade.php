@extends('app')
@section('title', 'Privacy Policy | ImgShare :: Upload & Share Images For Free')
@section('main')
<div class="mt-8 section px-4 flex flex-col gap-3">
    <h1 class="font-bold text-4xl">Privacy Policy for ImgShare</h1>

   
</div>
@endsection
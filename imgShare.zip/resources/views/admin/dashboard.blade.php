@extends('app')

@section('main')

<div class="section px-4 mt-6">
    <h1 class="text-center">Coming soon ...</h1>
</div>

@endsection
@extends('app')
@section('title', 'Terms of Use | ImgShare :: Upload & Share Images For Free')
@section('main')
<div class="mt-8 section px-4 flex flex-col gap-3">
    <h1 class="font-bold text-4xl">Terms of Use for ImgShare</h1>
    
</div>
@endsection
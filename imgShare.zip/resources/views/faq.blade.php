@extends('app')

@section('title', 'FAQ | ImgShare :: Upload & Share Images For Free')

@section('main')
<div class="mt-8 section px-4 flex flex-col gap-3">
    <h1 class="font-bold text-4xl">FAQs for ImgShare</h1>

</div>
@endsection
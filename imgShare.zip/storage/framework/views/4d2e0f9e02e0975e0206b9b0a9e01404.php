

<?php $__env->startSection('title', 'FAQ | ImgShare :: Upload & Share Images For Free'); ?>

<?php $__env->startSection('main'); ?>
<div class="mt-8 section px-4 flex flex-col gap-3">
    <h1 class="font-bold text-4xl">FAQs for ImgShare</h1>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Personal\imgShare\resources\views/faq.blade.php ENDPATH**/ ?>
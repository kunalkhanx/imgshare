

<?php $__env->startSection('title', 'FAQ | ToolBru Images :: Upload & Share Images For Free'); ?>

<?php $__env->startSection('main'); ?>
<div class="mt-8 section px-4 flex flex-col gap-3">
    <h1 class="font-bold text-4xl">FAQs for ToolBru Images</h1>

    <h2 class="text-2xl font-bold mt-6">What is ToolBru Images</h2>
    <p>ToolBru Images is a platform where users can upload images, also referred to as "Posts." These can be public or unlisted and will automatically be deleted after 7 days.</p>

    
    <h2 class="text-2xl font-bold mt-6">Do I need to create an account to upload images?</h2>
    <p>No, you do not need to create an account. Users can upload images without registration.</p>

    <h2 class="text-2xl font-bold mt-6">How long do Posts stay on the website?</h2>
    <p>All Posts are automatically deleted 7 days after they are uploaded.</p>

    <h2 class="text-2xl font-bold mt-6">Can I edit or delete a Post after uploading it?</h2>
    <p>No, once a Post is uploaded, it cannot be edited or deleted. Please ensure your content is final before submitting.</p>

    <h2 class="text-2xl font-bold mt-6">What does "Public" vs. "Unlisted" mean?</h2>
    <ul class="list-disc pl-5">
        <li><strong>Public Posts</strong> are visible to everyone and may appear in search results.</li>
        <li><strong>Unlisted Posts</strong> can only be accessed through a direct link and will not appear in public areas or search engines.</li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">What is NSFW content?</h2>
    <p>NSFW (Not Safe For Work) content refers to material unsuitable for general audiences. If you upload NSFW content, you must mark it appropriately. Viewers must confirm they are 18+ before accessing such content.</p>

    <h2 class="text-2xl font-bold mt-6">How does reporting work?</h2>
    <p>Each Post has a "Report" option. If someone finds a Post inappropriate or illegal, they can report it. We will review the report and take appropriate action.</p>

    <h2 class="text-2xl font-bold mt-6">Does the website use cookies?</h2>
    <p>No, the website does not use cookies. However, we track users' IP addresses to monitor visit counts and associate uploaded Posts with a source.</p>

    <h2 class="text-2xl font-bold mt-6">How do I contact the website team?</h2>
    <p>You can contact us at ToolBru Images for any questions or concerns.</p>

   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Personal\imgdost\resources\views/faq.blade.php ENDPATH**/ ?>
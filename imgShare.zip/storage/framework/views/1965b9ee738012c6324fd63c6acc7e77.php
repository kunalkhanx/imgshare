
<?php $__env->startSection('title', 'Privacy Policy | ToolBru Images :: Upload & Share Images For Free'); ?>
<?php $__env->startSection('main'); ?>
<div class="mt-8 section px-4 flex flex-col gap-3">
    <h1 class="font-bold text-4xl">Privacy Policy for ToolBru Images</h1>
    <p>Effective Date: 11-12-2024</p>

    <p>At ToolBru Images (the "Website"), your privacy is important to us. This Privacy Policy explains how we collect, use, and protect the information you provide when using our services. By accessing or using the Website, you agree to this Privacy Policy.</p>

    <h2 class="text-2xl font-bold mt-6">Information We Collect</h2>
    <p>The Website does not use cookies or similar tracking technologies. However, we collect the following information:</p>
    <ul class="list-disc pl-5">
        <li>IP Address:</li>
        <li class="list-none">
            <ul class="list-disc pl-5">
                <li>To track visit counts and monitor the usage of the Website.</li>
                <li>To associate uploaded Posts/Images with a source for ownership purposes and potential abuse prevention.</li>
            </ul>
        </li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">How We Use Your Information</h2>
    <p>We use the collected IP address for:</p>
    <ul class="list-disc pl-5">
        <li>Maintaining and analyzing visit counts to ensure the Website's functionality and growth.</li>
        <li>Determining the ownership of uploaded content to prevent misuse and respond to reports.</li>
        <li>Enhancing security measures to prevent fraudulent or abusive activity.</li>
    </ul>


    <h2 class="text-2xl font-bold mt-6">Data Retention</h2>
    <ul class="list-disc pl-5">
        <li>IP addresses associated with Posts/Images are stored temporarily for as long as the content is live on the Website (7 days). After the Post is automatically deleted, the related IP data is also permanently removed.</li>
        <li>Visit count data may be anonymized and retained for statistical purposes, but it cannot be traced back to individual users.</li>
    </ul>


    <h2 class="text-2xl font-bold mt-6">How We Protect Your Information</h2>
    <p>We take reasonable measures to protect the information we collect, including:</p>
    <ul class="list-disc pl-5">
        <li>Secure storage of IP addresses in our database.</li>
        <li>Limiting access to IP data to authorized personnel only.</li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">Sharing of Information</h2>
    <p>We do not sell, trade, or otherwise share your IP address or any other personal information with third parties, except:</p>
    <ul class="list-disc pl-5">
        <li><strong>When required by law:</strong> To comply with legal obligations, court orders, or law enforcement requests.</li>
        <li><strong>To address violations:</strong> When necessary to investigate or address violations of our Terms of Use, including inappropriate or illegal content.</li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">Your Privacy Choices</h2>
    <p>As the Website does not use cookies or require account registration, no additional settings or opt-outs are available. You may choose to stop using the Website if you do not agree with this policy.</p>


    <h2 class="text-2xl font-bold mt-6">Third-Party Links and Advertisements</h2>
    <p>The Website may display advertisements or links to third-party websites. We are not responsible for the privacy practices of these third parties. Please review their privacy policies before engaging with their services.</p>


    <h2 class="text-2xl font-bold mt-6">Children's Privacy</h2>
    <p>The Website is not intended for children under the age of 13. We do not knowingly collect personal information from children.</p>


    <h2 class="text-2xl font-bold mt-6">Changes to this Privacy Policy</h2>
    <p>We may update this Privacy Policy from time to time. Any changes will be posted on this page, and the "Effective Date" at the top will be updated. Continued use of the Website constitutes your acceptance of the revised policy.</p>


    <h2 class="text-2xl font-bold mt-6">Contact Information</h2>
    <p>If you have any questions or concerns about these Terms, please contact us at:</p>
    <p>contact@toolbru.com</p>

    <hr />

    <p>By using the Website, you acknowledge that you have read, understood, and agreed to this Privacy Policy. Thank you for trusting ToolBru Images!</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Personal\imgdost\resources\views/policy.blade.php ENDPATH**/ ?>
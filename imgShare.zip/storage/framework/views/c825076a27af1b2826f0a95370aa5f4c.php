

<?php $__env->startSection('main'); ?>

<div class="section px-4 mt-6">
    <h1 class="text-center">Coming soon ...</h1>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Personal\imgdost\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
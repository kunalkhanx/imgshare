
<?php $__env->startSection('title', 'Terms of Use | ToolBru Images :: Upload & Share Images For Free'); ?>
<?php $__env->startSection('main'); ?>
<div class="mt-8 section px-4 flex flex-col gap-3">
    <h1 class="font-bold text-4xl">Terms of Use for ToolBru Images</h1>
    <p>Effective Date: 11-12-2024</p>

    <p>Welcome to ToolBru Images (the "Website"). By accessing or using our Website, you agree to the following Terms of Use. Please read them carefully. If you do not agree to these terms, you may not use our services.</p>

    <h2 class="text-2xl font-bold mt-6">User Eligibility</h2>
    <p>You must be at least 13 years old or the age of majority in your jurisdiction to use this Website. To view content marked as "NSFW," you must confirm that you are 18 years of age or older.</p>

    <h2 class="text-2xl font-bold mt-6">Posting Images</h2>
    <ul class="list-disc pl-5">
        <li>Users can upload images ("Posts") without creating an account.</li>
        <li>When uploading, users must choose a visibility setting for their Posts:</li>
        <li class="list-none">
            <ul class="list-disc pl-5">
                <li><strong>Public:</strong> Posts are accessible to anyone and may appear in search engines or public areas of the Website.</li>
                <li><strong>Unlisted:</strong> Posts are accessible only via a direct URL. These Posts will not appear in public areas of the Website.</li>
            </ul>
        </li>
        <li>Editing or Deleting Posts:</li>
        <li class="list-none">
            <ul class="list-disc pl-5">
                <li>Once a Post is created and uploaded, it cannot be edited or deleted by the user.</li>
                <li>Posts will remain on the Website until their automatic deletion after 7 days. Users are advised to review their content carefully before uploading.</li>
            </ul>
        </li>
        <li>Posts may also be marked as NSFW (Not Safe For Work):</li>
        <li class="list-none">
            <ul class="list-disc pl-5">
                <li>NSFW Posts contain content deemed inappropriate for general audiences.</li>
                <li>Viewers attempting to access NSFW Posts will be required to confirm they are 18 years or older through a prompt.</li>
            </ul>
        </li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">Prohibited Content</h2>
    <p>You agree not to upload or share any content that:</p>
    <ul class="list-disc pl-5">
        <li>Violates any applicable laws or regulations.</li>
        <li>Contains nudity, sexually explicit material, or other offensive content that is not appropriately marked as NSFW.</li>
        <li>Promotes violence, hate speech, or illegal activities.</li>
        <li>Infringes on intellectual property rights or the privacy of others.</li>
    </ul>
    <p>We reserve the right to remove content that violates these terms or is not appropriately labeled as NSFW.</p>


    <h2 class="text-2xl font-bold mt-6">Reporting Posts</h2>
    <ul class="list-disc pl-5">
        <li>The Website provides a "Report" option for every Post.</li>
        <li>Viewers can report Posts they find inappropriate, illegal, or in violation of these Terms of Use.</li>
        <li>Reports will be reviewed, and appropriate action will be taken, which may include removing the content.</li>
    </ul>


    <h2 class="text-2xl font-bold mt-6">Privacy</h2>
    <ul class="list-disc pl-5">
        <li><span>Public Posts:</span> May be viewed and shared by anyone.</li>
        <li><span>Unlisted Posts:</span> Accessible only to those with the direct URL, but sharing the URL may result in wider distribution.</li>
        <li>All Posts, including NSFW content, are temporary and will be deleted after 7 days, regardless of their visibility setting.</li>
        <li>For more information, please review our <a href="<?php echo e(route('policy')); ?>" class="text-blue-500">Privacy Policy</a>.</li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">NSFW Content Guidelines</h2>
    <ul class="list-disc pl-5">
        <li>Users are responsible for marking their Posts as NSFW if they contain content unsuitable for general audiences.</li>
        <li>Viewers must confirm they are 18 years or older before accessing NSFW Posts.</li>
        <li>The Website does not verify the accuracy of viewer confirmations and is not liable for any misrepresentation.</li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">Intellectual Property</h2>
    <p>By uploading Posts, you grant the Website a non-exclusive, worldwide, royalty-free license to display, distribute, and promote your content within the Website's platform and related services during the 7-day validity period.</p>

    <h2 class="text-2xl font-bold mt-6">Advertising</h2>
    <ul class="list-disc pl-5">
        <li>The Website may display advertisements from third-party providers.</li>
        <li>These ads are served by third parties, and we are not responsible for the content or accuracy of the advertisements or the services they promote.</li>
        <li>Clicking on advertisements may redirect you to third-party websites with their own terms and privacy policies.</li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">Limitations of Liability</h2>
    <ul class="list-disc pl-5">
        <li>The Website is provided "as is," and we make no warranties regarding its performance or availability.</li>
        <li>We are not responsible for any damages resulting from the use of the Website or the inability to use it.</li>
        <li>Users are solely responsible for the content they upload and share.</li>
    </ul>

    <h2 class="text-2xl font-bold mt-6">Termination</h2>
    <p>We reserve the right to remove content or restrict access to the Website for violations of these Terms or other reasons.</p>

    <h2 class="text-2xl font-bold mt-6">Modifications</h2>
    <p>We may update these Terms of Use at any time. Changes will be effective immediately upon posting to this page. Continued use of the Website constitutes acceptance of the revised Terms.</p>

    <h2 class="text-2xl font-bold mt-6">Contact Information</h2>
    <p>If you have any questions or concerns about these Terms, please contact us at:</p>
    <p>contact@toolbru.com</p>

    <hr />

    <p>By using the Website, you acknowledge that you have read, understood, and agreed to these Terms of Use. Thank you for using ToolBru Images!</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Personal\imgdost\resources\views/terms.blade.php ENDPATH**/ ?>